injectCode = `
class Modifier {
    constructor() {
        this.result = [];
        this.mark = new WeakSet();
        this.initListener();
    }
    initListener() {
        window.addEventListener('message', function (event) {
            let msg = event.data;
            try {
                if (msg.cmd && msg.cmd.startsWith('C2T_')) {
                    this[msg.cmd](...msg.param);
                }
            }
            catch (e) {
                this.sendMessage('recvError', msg.cmd);
            }
        }.bind(this), false);
    }
    sendMessage(cmd, ...param) {
        let msg = {};
        msg.cmd = cmd;
        msg.param = param;
        window.postMessage(msg, "*");
    }
    C2T_Find(val) {
        setTimeout(() => {
            this.val = val;
            this.result = [];
            this.pathStack = [];
            this.initMark();
            this.findPath(window, 'window');
            let result = this.result.slice(0, 128);
            this.sendMessage('T2C_Result', result);
        });
    }
    C2T_FindAgain(val) {
        setTimeout(() => {
            this.val = val;
            this.findPathAgain();
            let result = this.result.slice(0, 128);
            this.sendMessage('T2C_Result', result);
        });
    }
    C2T_Modify(val, path) {
        try {
            eval(path + '=' + val);
        }
        catch (e) {
        }
    }
    initMark() {
        let omit = ["$", "speechSynthesis", "caches", "stop", "open", "alert", "confirm", "prompt", "print", "requestAnimationFrame", "cancelAnimationFrame", "requestIdleCallback", "cancelIdleCallback", "captureEvents", "releaseEvents", "getComputedStyle", "matchMedia", "moveTo", "moveBy", "resizeTo", "resizeBy", "getSelection", "find", "getMatchedCSSRules", "webkitRequestAnimationFrame", "webkitCancelAnimationFrame", "webkitCancelRequestAnimationFrame", "btoa", "atob", "setTimeout", "localStorage", "clearTimeout", "sessionStorage", "setInterval", "clearInterval", "createImageBitmap", "scroll", "scrollTo", "indexedDB", "scrollBy", "webkitIndexedDB", "ondeviceorientationabsolute", "fetch", "ondeviceorientation", "ondevicemotion", "crypto", "webkitRequestFileSystem", "postMessage", "blur", "webkitResolveLocalFileSystemURL", "focus", "openDatabase", "close", "onpointerup", "onpointerover", "onpointerout", "onpointermove", "onpointerleave", "onpointerenter", "onpointerdown", "onpointercancel", "chrome", "console", "customElements", "onauxclick", "performance", "onunload", "onunhandledrejection", "onstorage", "onrejectionhandled", "onpopstate", "onpageshow", "onpagehide", "ononline", "onoffline", "onmessage", "onlanguagechange", "onhashchange", "onbeforeunload", "onwaiting", "onvolumechange", "ontoggle", "ontimeupdate", "onsuspend", "onsubmit", "onstalled", "onshow", "onselect", "onseeking", "onseeked", "onscroll", "onresize", "onreset", "onratechange", "onprogress", "onplaying", "onplay", "onpause", "onmousewheel", "onmouseup", "onmouseover", "onmouseout", "onmousemove", "onmouseleave", "onmouseenter", "onmousedown", "onloadstart", "onloadedmetadata", "onloadeddata", "onload", "onkeyup", "onkeypress", "onkeydown", "oninvalid", "oninput", "onfocus", "onerror", "onended", "onemptied", "ondurationchange", "ondrop", "ondragstart", "ondragover", "ondragleave", "ondragenter", "ondragend", "ondrag", "ondblclick", "oncuechange", "oncontextmenu", "onclose", "onclick", "onchange", "oncanplaythrough", "oncanplay", "oncancel", "onblur", "onabort", "onwheel", "onwebkittransitionend", "onwebkitanimationstart", "onwebkitanimationiteration", "onwebkitanimationend", "ontransitionend", "onsearch", "onanimationstart", "onanimationiteration", "onanimationend", "styleMedia", "clientInformation", "screen", "external", "applicationCache", "navigator", "parent", "opener", "top", "toolbar", "statusbar", "scrollbars", "personalbar", "menubar", "locationbar", "history", "location", "self", "window"];
        this.mark = new WeakSet();
        for (let i of omit) {
            if (window[i] && window[i] !== window)
                this.mark.add(window[i]);
        }
    }
    getPath() {
        let path = 'window';
        for (let i = 1; i < this.pathStack.length; i++) {
            let key = this.pathStack[i];
            if (typeof key == 'number' || !isNaN(Number(key))) {
                path += '[' + key + ']';
            }
            else {
                path += '.' + key;
            }
        }
        this.pathStack.pop();
        return path;
    }
    findPathAgain() {
        let res = [];
        for (let i of this.result) {
            try {
                if (eval(i) === this.val) {
                    res.push(i);
                }
            }
            catch (e) {
            }
        }
        this.result = res;
    }
    findPath(parent, key) {
        if (parent != null && parent != undefined && !this.mark.has(parent)) {
            this.mark.add(parent);
            this.pathStack.push(key);
            for (let childKey of Object.keys(parent)) {
                try {
                    if (childKey == 'webkitStorageInfo') {
                        continue;
                    }
                    let child = parent[childKey];
                    switch (typeof child) {
                        case 'object':
                        case 'function':
                            this.findPath(child, childKey);
                            break;
                        case 'number':
                        case 'boolean':
                            if (this.val === child) {
                                this.pathStack.push(childKey);
                                this.result.push(this.getPath());
                            }
                            break;
                    }
                }
                catch (e) {
                }
            }
            this.pathStack.pop();
        }
    }
}
Modifier.H = new Modifier();

`
var injectCode;
class App {
    constructor() {
        this.initInject();
        this.initListener();
        this.initData();
    }
    initData() {
        this.data = {};
        this.data.findVal = 0;
        this.data.firstFind = true;
        this.data.modifyVal = 0;
        this.data.result = [];
        this.data.selected = -1;
        this.data.frames = [];
        let ns = window.document.getElementsByTagName('iframe');
        for (let n of ns) {
            if (n && n.src && n.src != 'about:blank' && n.src != 'about:block')
                this.data.frames.push(n.src);
        }
    }
    initInject() {
        let head = document.getElementsByTagName('head')[0];
        this.inject = document.createElement('script');
        this.inject.type = 'text/javascript';
        this.inject.id = 'inject';
        if (injectCode) {
            this.inject.text = injectCode;
        }
        head.appendChild(this.inject);
    }
    initListener() {
        window.addEventListener('message', function (event) {
            let msg = event.data;
            try {
                if (msg.cmd && msg.cmd.startsWith('T2C_')) {
                    this[msg.cmd](...msg.param);
                }
            }
            catch (e) {
            }
        }.bind(this), false);
        chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
            let msg = request;
            try {
                if (msg.cmd && msg.cmd.startsWith('P2C_')) {
                    this[msg.cmd](...msg.param);
                }
            }
            catch (e) {
            }
        }.bind(this));
    }
    P2C_Find(val) {
        this.data.firstFind = false;
        this.data.findVal = val;
        this.sendMessage('C2T_Find', this.data.findVal);
    }
    P2C_FindAgain(val) {
        this.data.findVal = val;
        this.sendMessage('C2T_FindAgain', val);
    }
    P2C_Modify(val, selected) {
        this.data.modifyVal = val;
        this.data.selected = selected;
        this.sendMessage('C2T_Modify', val, this.data.result[selected]);
    }
    P2C_Reset() {
        this.initData();
        this.sendMessage2Popup('C2P_Sync', this.data);
    }
    P2C_Sync() {
        if (!this.data)
            this.initData();
        this.sendMessage2Popup('C2P_Sync', this.data);
    }
    sendMessage(cmd, ...param) {
        let msg = {};
        msg.cmd = cmd;
        msg.param = param;
        window.postMessage(msg, '*');
    }
    sendMessage2Popup(cmd, ...param) {
        let msg = {};
        msg.cmd = cmd;
        msg.param = param;
        chrome.runtime.sendMessage(msg);
    }
    T2C_Result(result) {
        this.data.result = result;
        this.sendMessage2Popup('C2P_Sync', this.data);
    }
}
App.H = new App();
