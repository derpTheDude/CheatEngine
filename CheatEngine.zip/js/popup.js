class Popup {
    constructor() {
        this.firstIn = true;
        this.initListener();
        this.sendMessage('P2C_Sync');
    }
    initListener() {
        chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
            let msg = request;
            try {
                if (msg.cmd && msg.cmd.startsWith('C2P_')) {
                    this[msg.cmd](...msg.param);
                }
            }
            catch (e) {
            }
        }.bind(this));
    }
    C2P_Sync(data) {
        this.data = data;
        this.updateUI();
        if (this.firstIn) {
            this.updateFrame();
            this.firstIn = false;
        }
    }
    locale(id, msg) {
        let n = document.getElementById(id);
        if (n)
            n.innerHTML = msg ? chrome.i18n.getMessage(msg) : chrome.i18n.getMessage(id);
    }
    display(id, disp) {
        let n = document.getElementById(id);
        if (n)
            n.style.display = disp ? 'inline' : 'none';
    }
    enableButton(id, enable = true) {
        let n = document.getElementById(id);
        if (n)
            n.disabled = !enable;
    }
    clickButton(id, callback) {
        let n = document.getElementById(id);
        if (n)
            n.addEventListener('click', callback);
    }
    updateInput(id, val) {
        let node = document.getElementById(id);
        if (node && val)
            node.value = val.toString();
    }
    updateList(id, data, selected) {
        let n = document.getElementById(id);
        if (n && data) {
            n.options.length = 0;
            for (let i of data) {
                let option = document.createElement('option');
                if (i.length > 25)
                    option.innerHTML = i.slice(i.length - 25, i.length);
                else
                    option.innerHTML = i;
                n.options.add(option);
            }
            if (selected >= 0 && selected < n.options.length) {
                n.selectedIndex = selected;
            }
            else if (n.options.length == 1) {
                n.selectedIndex = 0;
            }
        }
    }
    localeHolder(id) {
        let n = document.getElementById(id);
        if (n)
            n.placeholder = chrome.i18n.getMessage(id);
    }
    sendMessage(cmd, ...param) {
        let msg = {};
        msg.cmd = cmd;
        msg.param = param;
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, msg);
        });
    }
    onClickFind() {
        let n = document.getElementById('txtFind');
        if (isNaN(n.value))
            return;
        if (this.data.firstFind) {
            this.sendMessage('P2C_Find', Number(n.value));
        }
        else {
            this.sendMessage('P2C_FindAgain', Number(n.value));
        }
    }
    onClickModify() {
        let n = document.getElementById('txtModify');
        let list = document.getElementById('listResult');
        if (isNaN(n.value))
            return;
        this.sendMessage('P2C_Modify', Number(n.value), list.selectedIndex);
    }
    onClickReset() {
        this.sendMessage('P2C_Reset');
    }
    updateFrame() {
        if (this.data.frames.length > 0) {
            this.display('stFrame', true);
            let hr = document.getElementById('hrFrame');
            for (let f of this.data.frames) {
                let a = document.createElement('a');
                a.href = f;
                a.text = f.slice(0, 32);
                a.target = "_blank";
                hr.parentNode.insertBefore(document.createElement('br'), hr);
                hr.parentNode.insertBefore(a, hr);
            }
        }
        else {
            this.display('stFrame', false);
            this.display('hrFrame', false);
        }
    }
    updateUI() {
        this.localeHolder('txtFind');
        this.localeHolder('txtModify');
        this.locale('btnModify');
        this.locale('stResult');
        this.locale('stFrame');
        this.locale('btnReset');
        this.clickButton('btnReset', this.onClickReset.bind(this));
        this.clickButton('btnFind', this.onClickFind.bind(this));
        this.clickButton('btnModify', this.onClickModify.bind(this));
        if (this.data.firstFind) {
            this.locale('btnFind');
            this.enableButton('btnReset', false);
        }
        else {
            this.locale('btnFind', 'btnFindAgain');
            this.enableButton('btnReset', true);
        }
        this.updateInput('txtFind', this.data.findVal);
        this.updateInput('txtModify', this.data.modifyVal);
        this.updateList('listResult', this.data.result, this.data.selected);
    }
}
window.onload = () => {
    if (!Popup.H) {
        Popup.H = new Popup();
    }
};
